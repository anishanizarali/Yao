#include "../../include/pkg/evaluator.hpp"
#include "../../include-shared/constants.hpp"
#include "../../include-shared/util.hpp"
#include "../../include-shared/logger.hpp"

/*
Syntax to use logger: 
  CUSTOM_LOG(lg, debug) << "your message"
See logger.hpp for more modes besides 'debug'
*/
namespace {
  src::severity_logger<logging::trivial::severity_level> lg;
}

/**
 * Constructor. Note that the OT_driver is left uninitialized.
 */
EvaluatorClient::EvaluatorClient(Circuit circuit,std::shared_ptr<NetworkDriver> network_driver,                       std::shared_ptr<CryptoDriver> crypto_driver) {
  this->circuit = circuit;
  this->network_driver = network_driver;
  this->crypto_driver = crypto_driver;
  this->cli_driver = std::make_shared<CLIDriver>();
}

/**
 * Handle key exchange with evaluator
 */
std::pair<CryptoPP::SecByteBlock, CryptoPP::SecByteBlock>EvaluatorClient::HandleKeyExchange() {
  // Generate private/public DH keys
  auto dh_values = this->crypto_driver->DH_initialize();

  // Listen for g^b
  std::vector<unsigned char> garbler_public_value_data = network_driver->read();
  DHPublicValue_Message garbler_public_value_s;
  garbler_public_value_s.deserialize(garbler_public_value_data);

  // Send g^a
  DHPublicValue_Message evaluator_public_value_s;
  evaluator_public_value_s.public_value = std::get<2>(dh_values);
  std::vector<unsigned char> evaluator_public_value_data;
  evaluator_public_value_s.serialize(evaluator_public_value_data);
  network_driver->send(evaluator_public_value_data);

  // Recover g^ab
  CryptoPP::SecByteBlock DH_shared_key = crypto_driver->DH_generate_shared_key(std::get<0>(dh_values), std::get<1>(dh_values),    garbler_public_value_s.public_value);
  CryptoPP::SecByteBlock AES_key = this->crypto_driver->AES_generate_key(DH_shared_key);
  CryptoPP::SecByteBlock HMAC_key = this->crypto_driver->HMAC_generate_key(DH_shared_key);
  auto keys = std::make_pair(AES_key, HMAC_key);
  this->ot_driver = std::make_shared<OTDriver>(network_driver, crypto_driver, keys);
  return keys;
}

/**
 * run. This function should:
 * 1) Receive the garbled circuit and the garbler's input
 * 2) Reconstruct the garbled circuit and input the garbler's inputs
 * 3) Retrieve evaluator's inputs using OT
 * 4) Evaluate gates in order (use `GarbledCircuit::evaluate_gate` to help!)
 * 5) Send final labels to the garbler
 * 6) Receive final output
 * `input` is the evaluator's input for each gate
 * You may find `string_to_byteblock` useful for converting OT output to wires
 * Disconnect and throw errors only for invalid MACs
 */
std::string EvaluatorClient::run(std::vector<int> input) {
  // Key exchange
  auto keys = this->HandleKeyExchange();

  // Receive garbled circuit and garbler's input
  auto circuit_bytes = this->sock->recv();
  auto input_bytes = this->sock->recv();
  auto circuit = GarbledCircuit::from_bytes(circuit_bytes);
  auto garbler_input = string_to_byteblock(input_bytes);

  // Reconstruct garbled circuit and set garbler's input
  circuit.reconstruct(keys, garbler_input);

  // Receive evaluator's input labels using OT
  std::vector<CryptoPP::SecByteBlock> evaluator_input;
  for (int i = 0; i < input.size(); i++) {
    auto label = this->ot_driver->OT_recv(input[i]);
    auto wire = byteblock_to_wire(label);
    evaluator_input.push_back(wire);
  }

  // Evaluate gates in order
  for (int i = 0; i < circuit.gates.size(); i++) {
    auto gate = circuit.gates[i];
    circuit.evaluate_gate(gate, evaluator_input);
  }

  // Send final labels to garbler
  this->sock->send(circuit.output_label[0]);
  this->sock->send(circuit.output_label[1]);

  // Receive final output
  auto output_bytes = this->sock->recv();
  auto output = byteblock_to_integer(output_bytes);
  auto final_output = std::bitset<MAX_WIRE_LABEL_LENGTH>(output).to_string();
  return final_output.substr(MAX_WIRE_LABEL_LENGTH - circuit.output_size);
}


/**
 * Evaluate gate.
 * You may find CryptoPP::xorbuf and util::hash_label useful.
 * To determine if a decryption is valid, use verify_decryption.
 * To retrieve the label from a decryption, use snip_decryption.
 */
GarbledWire EvaluatorClient::evaluate_gate(GarbledGate gate, GarbledWire lhs,GarbledWire rhs) {
  // Retrieve the label corresponding to the input wires and the gate type
  CryptoPP::SecByteBlock label = gate.table[lhs.label ^ gate.xor_lhs][rhs.label ^ gate.xor_rhs];
  
  // Decrypt the label
  CryptoPP::SecByteBlock decrypted_label;
  bool decryption_valid = this->crypto.decrypt_with_mac(label, decrypted_label, gate.mac);
  
  if (!decryption_valid) {
    throw std::runtime_error("Invalid MAC for gate label decryption");
  }
  
  // Snip the decrypted label to get the wire label and the tag
  CryptoPP::SecByteBlock tag(util::LABEL_TAG_LENGTH);
  CryptoPP::xorbuf(tag, decrypted_label, decrypted_label.size() - util::LABEL_TAG_LENGTH, tag.size());
  
  // Hash the wire label and compare with the tag to check for consistency
  CryptoPP::SecByteBlock hash(util::HASH_LENGTH);
  this->crypto.hash_label(lhs.label, rhs.label, hash);
  if (CryptoPP::compare_mem(tag, tag.size(), hash, hash.size()) != 0) {
    throw std::runtime_error("Inconsistent tag and wire label in gate");
  }
  
  // Extract the wire value from the decrypted label
  bool wire_value = decrypted_label[decrypted_label.size() - 1];
  
  // Return the output wire with the correct label
  return GarbledWire(label, wire_value);
}


/**
 * Verify decryption. A valid dec should end with LABEL_TAG_LENGTH bits of 0s.
 */
bool EvaluatorClient::verify_decryption(CryptoPP::SecByteBlock decryption) {
  CryptoPP::SecByteBlock trail(decryption.data() + LABEL_LENGTH,LABEL_TAG_LENGTH);
  return byteblock_to_integer(trail) == CryptoPP::Integer::Zero();
}

/**
 * Returns the first LABEL_LENGTH bits of a decryption.
 */
CryptoPP::SecByteBlock EvaluatorClient::snip_decryption(CryptoPP::SecByteBlock decryption) {
  CryptoPP::SecByteBlock head(decryption.data(), LABEL_LENGTH);
  return head;
}
