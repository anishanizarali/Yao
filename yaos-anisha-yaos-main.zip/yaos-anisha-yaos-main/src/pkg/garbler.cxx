#include <algorithm>
#include <crypto++/misc.h>

#include "../../include-shared/constants.hpp"
#include "../../include-shared/util.hpp"
#include "../../include/pkg/garbler.hpp"
#include "../../include-shared/logger.hpp"

namespace {
  src::severity_logger<logging::trivial::severity_level> lg;
}

/**
 * Constructor. Note that the OT_driver is left uninitialized.
 */
GarblerClient::GarblerClient(Circuit circuit,std::shared_ptr<NetworkDriver> network_driver,                        std::shared_ptr<CryptoDriver> crypto_driver) {
  this->circuit = circuit;
  this->network_driver = network_driver;
  this->crypto_driver = crypto_driver;
  this->cli_driver = std::make_shared<CLIDriver>();
}

std::pair<CryptoPP::SecByteBlock, CryptoPP::SecByteBlock>GarblerClient::HandleKeyExchange() {
  // Generate private/public DH keys
  auto dh_values = this->crypto_driver->DH_initialize();

  // Send g^b
  DHPublicValue_Message garbler_public_value_s;
  garbler_public_value_s.public_value = std::get<2>(dh_values);
  std::vector<unsigned char> garbler_public_value_data;
  garbler_public_value_s.serialize(garbler_public_value_data);
  network_driver->send(garbler_public_value_data);

  // Listen for g^a
  std::vector<unsigned char> evaluator_public_value_data = network_driver->read();
  DHPublicValue_Message evaluator_public_value_s;
  evaluator_public_value_s.deserialize(evaluator_public_value_data);

  // Recover g^ab
  CryptoPP::SecByteBlock DH_shared_key = crypto_driver->DH_generate_shared_key(std::get<0>(dh_values), std::get<1>(dh_values),     evaluator_public_value_s.public_value);
  CryptoPP::SecByteBlock AES_key = this->crypto_driver->AES_generate_key(DH_shared_key);
  CryptoPP::SecByteBlock HMAC_key = this->crypto_driver->HMAC_generate_key(DH_shared_key);
  auto keys = std::make_pair(AES_key, HMAC_key);
  this->ot_driver = std::make_shared<OTDriver>(network_driver, crypto_driver, keys);
  return keys;
}

/**
 * run. This function should:
 * 1) Generate a garbled circuit from the given circuit in this->circuit
 * 2) Send the garbled circuit to the evaluator
 * 3) Send garbler's input labels in the clear
 * 4) Send evaluator's input labels using OT
 * 5) Receive final labels, recover and reveal final output
 * `input` is the evaluator's input for each gate
 * Final output should be a string containing only "0"s or "1"s
 * Throw errors only for invalid MACs
 */
std::string GarblerClient::run(std::vector<int> input) {
  // Key exchange
  auto keys = this->HandleKeyExchange();

  // Generate garbled circuit
  auto gc = this->circuit->garble(keys);

  // Send garbled circuit to evaluator
  this->SendGarbledCircuit(gc);

  // Generate an AES key and an HMAC key for encrypting and authenticating messages
  CryptoPP::SecByteBlock aes_key = this->crypto_driver->AES_generate_key(Constants::AES_KEY_SIZE);
  CryptoPP::SecByteBlock hmac_key = this->crypto_driver->HMAC_generate_key(Constants::HMAC_KEY_SIZE);

  // Initialize the OT driver with the generated keys
  this->ot_driver = std::make_shared<OTDriver>(this->network_driver, this->crypto_driver, std::make_pair(aes_key, hmac_key));

  // Send garbler's input labels in the clear
  std::vector<BitArray> garbler_input_labels;
  for (int i = 0; i < this->circuit->num_gates; i++) {
    if (this->circuit->gate_types[i] == GateType::INPUT_A) {
      garbler_input_labels.push_back(gc->input_labels_A[i]);
    } else if (this->circuit->gate_types[i] == GateType::INPUT_B) {
      garbler_input_labels.push_back(gc->input_labels_B[i]);
    }
  }
  this->SendLabels(garbler_input_labels);

  // Send evaluator's input labels using OT
  std::vector<BitArray> evaluator_input_labels;
  for (int i = 0; i < this->circuit->num_gates; i++) {
    if (this->circuit->gate_types[i] == GateType::INPUT_A && input[i] == 0) {
      evaluator_input_labels.push_back(gc->input_labels_A[i]);
    } else if (this->circuit->gate_types[i] == GateType::INPUT_A && input[i] == 1) {
      evaluator_input_labels.push_back(gc->input_labels_A[i] ^ gc->delta);
    } else if (this->circuit->gate_types[i] == GateType::INPUT_B && input[i] == 0) {
      evaluator_input_labels.push_back(gc->input_labels_B[i]);
    } else if (this->circuit->gate_types[i] == GateType::INPUT_B && input[i] == 1) {
      evaluator_input_labels.push_back(gc->input_labels_B[i] ^ gc->delta);
    }
  }
  std::vector<std::string> evaluator_labels_str = this->OTLabels(evaluator_input_labels);
  std::vector<BitArray> evaluator_labels;
  for (const auto& label_str : evaluator_labels_str) {
    evaluator_labels.push_back(BitArray::from_string(label_str));
  }

  // Receive final labels, recover and reveal final output
  BitArray output_label = gc->evaluate(evaluator_labels);
  std::string output = output_label.to_string();
  return output;
}
/**
 * Generate the gates for the circuit.
 * You may find `std::random_shuffle` useful
 */
/**
 * Generate the gates for the circuit.
 * You may find `std::random_shuffle` useful
 */
std::vector<GarbledGate> GarblerClient::generate_gates(Circuit circuit, GarbledLabels labels) {
  std::vector<GarbledGate> garbled_gates;
  std::vector<int> indices(this->circuit->num_gates);
  for (int i = 0; i < indices.size(); i++) {
      indices[i] = i;
  }

  // Randomly shuffle the indices vector to generate a random order for the gates
  std::random_shuffle(indices.begin(), indices.end());

  for (int i = 0; i < this->circuit->num_gates; i++) {
      GarbledGate garbled_gate;

      int index = indices[i];
      GateType gate_type = circuit->gate_types[index];
      BitArray input_wire_A = labels.input_labels_A[index];
      BitArray input_wire_B = labels.input_labels_B[index];

      switch (gate_type) {
          case GateType::AND:
              BitArray output_wire_AND = labels.output_labels[index];
              garbled_gate = GarbledGate::garble_AND(input_wire_A, input_wire_B, output_wire_AND, ot_driver);
              break;
          case GateType::OR:
              BitArray output_wire_OR = labels.output_labels[index];
              garbled_gate = GarbledGate::garble_OR(input_wire_A, input_wire_B, output_wire_OR, ot_driver);
              break;
          case GateType::NOT:
              BitArray output_wire_NOT = labels.output_labels[index];
              garbled_gate = GarbledGate::garble_NOT(input_wire_A, output_wire_NOT);
              break;
          case GateType::XOR:
              BitArray output_wire_XOR = labels.output_labels[index];
              garbled_gate = GarbledGate::garble_XOR(input_wire_A, input_wire_B, output_wire_XOR);
              break;
          case GateType::INPUT_A:
          case GateType::INPUT_B:
          case GateType::OUTPUT:
              // These gates do not need to be garbled, so we skip them
              continue;
          default:
              BOOST_LOG_SEV(lg, logging::trivial::error) << "Invalid gate type: " << (int)gate_type;
              throw std::runtime_error("Invalid gate type");
      }

      garbled_gates.push_back(garbled_gate);
    }
    return garbled_gates;
  }

  /**
   * Generate *all* labels for the circuit. 
   * To generate an individual label, use `generate_label`.
   */
  GarbledLabels GarblerClient::generate_labels(Circuit circuit) {
    GarbledLabels labels;
    for (auto& gate : circuit) {
      for (int i = 0; i < 2; i++) {
        labels[gate.inputs[i]][i] = generate_label();
      }
      labels[gate.output][2] = generate_label();
    }
    return labels;
}
/**
 * Generate encrypted label. Tags LABEL_TAG_LENGTH trailing 0s to end before encrypting.
 * You may find CryptoPP::xorbuf and CryptoDriver::hash_label useful.
 */
CryptoPP::SecByteBlock GarblerClient::encrypt_label(GarbledWire lhs,GarbledWire rhs,                                                  GarbledWire output) {
  // concatenate the two input labels
  std::string input = lhs.label.to_string() + rhs.label.to_string();

  // add trailing zeros
  input.resize(LABEL_TAG_LENGTH, '0');

  // encrypt using the output label as the key
  CryptoPP::SecByteBlock key((const byte*) output.label.to_string().c_str(),output.label.size());
  CryptoPP::SecByteBlock ciphertext(input.size());

  CryptoPP::xorbuf(ciphertext, (const byte*) input.c_str(),(const byte*) key.begin(), input.size());

  // hash the output label and add it as a tag to the ciphertext
  CryptoPP::SecByteBlock tag = CryptoDriver::hash_label(output.label);
  ciphertext += tag;

  return ciphertext;
}
/**
 * Generate label.
 */
CryptoPP::SecByteBlock GarblerClient::generate_label() {
  CryptoPP::SecByteBlock label(LABEL_LENGTH);
  CryptoPP::OS_GenerateRandomBlock(false, label, label.size());
  return label;
}

/*
 * Given a set of 0/1 labels and an input vector of 0's and 1's, returns the
 * labels corresponding to the inputs starting at begin.
 */
std::vector<GarbledWire>GarblerClient::get_garbled_wires(GarbledLabels labels, std::vector<int> input,int begin) {
  std::vector<GarbledWire> res;
  for (int i = 0; i < input.size(); i++) {
    switch (input[i]) {
    case 0:
      res.push_back(labels.zeros[begin + i]);
      break;
    case 1:
      res.push_back(labels.ones[begin + i]);
      break;
    default:
      std::cerr << "INVALID INPUT CHARACTER" << std::endl;
    }
  }
  return res;
}
