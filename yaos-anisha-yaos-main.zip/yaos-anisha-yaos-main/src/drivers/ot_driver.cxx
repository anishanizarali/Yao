#include <iostream>
#include <stdexcept>
#include <string>

#include "crypto++/base64.h"
#include "crypto++/dsa.h"
#include "crypto++/osrng.h"
#include "crypto++/rsa.h"
#include <crypto++/cryptlib.h>
#include <crypto++/elgamal.h>
#include <crypto++/files.h>
#include <crypto++/hkdf.h>
#include <crypto++/nbtheory.h>
#include <crypto++/queue.h>
#include <crypto++/sha.h>

#include "../../include-shared/constants.hpp"
#include "../../include-shared/messages.hpp"
#include "../../include-shared/util.hpp"
#include "../../include/drivers/ot_driver.hpp"

/*
 * Constructor
 */
OTDriver::OTDriver(
    std::shared_ptr<NetworkDriver> network_driver,
    std::shared_ptr<CryptoDriver> crypto_driver,
    std::pair<CryptoPP::SecByteBlock, CryptoPP::SecByteBlock> keys) {
  this->network_driver = network_driver;
  this->crypto_driver = crypto_driver;
  this->AES_key = keys.first;
  this->HMAC_key = keys.second;
  this->cli_driver = std::make_shared<CLIDriver>();
}

/*
 * Send either m0 or m1 using OT. This function should:
 * 1) Sample a public DH value and send it to the receiver
 * 2) Receive the receiver's public value
 * 3) Encrypt m0 and m1 using different keys
 * 4) Send the encrypted values
 * You may find `byteblock_to_integer` and `integer_to_byteblock` useful
 * Disconnect and throw errors only for invalid MACs
 */

void OTDriver::OT_send(std::string m0, std::string m1) {
  // Initialize the DH key exchange
  DH dh;
  AutoSeededRandomPool rng;

  // Generate the sender's public key
  dh.AccessGroupParameters().GenerateRandomPrivateKey(rng);
  dh.GeneratePublicKey();

  // Send the sender's public key to the receiver
  auto sender_public_key = dh.GetPublicKey().GetGroupParameters().EncodePoint(dh.GetPublicKey());
  std::string sender_public_key_str(sender_public_key.begin(), sender_public_key.end());

  // Receive the receiver's public key
  std::string receiver_public_key_str;
  channel.receive(receiver_public_key_str);
  StringSource receiver_public_key_source(receiver_public_key_str, true);
  DH::Domain dh_params(receiver_public_key_source);
  dh.SetGroupParameters(dh_params);
  dh.GeneratePrivateKey();
  dh.GeneratePublicKey();

  // Compute the shared secret key
  SecByteBlock shared_secret(dh.AgreedValueLength());
  if (!dh.Agree(shared_secret, dh_params.DecodePoint(receiver_public_key_source))) {
    throw std::runtime_error("Failed to compute shared secret key");
  }

  // Encrypt m0 and m1 using different keys
  SecByteBlock key_m0(AES::DEFAULT_KEYLENGTH);
  SecByteBlock key_m1(AES::DEFAULT_KEYLENGTH);
  rng.GenerateBlock(key_m0, key_m0.size());
  rng.GenerateBlock(key_m1, key_m1.size());

  byteblock_to_integer(key_m0);
  byteblock_to_integer(key_m1);

  std::string m0_encrypted, m1_encrypted;
  AES encryption_m0(key_m0, key_m0.size());
  AES encryption_m1(key_m1, key_m1.size());
  StringSource(m0, true, new StreamTransformationFilter(encryption_m0, new StringSink(m0_encrypted)));
  StringSource(m1, true, new StreamTransformationFilter(encryption_m1, new StringSink(m1_encrypted)));

  // Compute the MAC
  std::string mac_str = compute_hmac_sha256(
      HMAC_key, sender_public_key_str + receiver_public_key_str + m0_encrypted + m1_encrypted);

  // Send the MAC and the encrypted values to the receiver
  if (channel.send(choice_bit)) {
    channel.send(m0_encrypted);
  } else {
    channel.send(m1_encrypted);
  }
  channel.send(sender_public_key_str);
  channel.send(mac_str);
}



/*
 * Receive m_c using OT. This function should:
 * 1) Read the sender's public value
 * 2) Respond with our public value that depends on our choice bit
 * 3) Generate the appropriate key and decrypt the appropriate ciphertext
 * You may find `byteblock_to_integer` and `integer_to_byteblock` useful
 * Disconnect and throw errors only for invalid MACs
 */

std::string OTDriver::OT_recv(int choice_bit) {
  // Receive the sender's public key
  std::string sender_public_key_str;
  channel.receive(sender_public_key_str);
  StringSource sender_public_key_source(sender_public_key_str, true);
  DH::Domain dh_params(sender_public_key_source);
  DH dh;
  dh.SetGroupParameters(dh_params);

  // Respond with our public key depending on our choice bit
  if (choice_bit == 0) {
    auto pub = dh.GetPublicKey().GetGroupParameters().EncodePoint(dh.GetPublicKey());
    channel.send(std::string(pub.begin(), pub.end()));
  } else {
    auto sender_pub = dh_params.DecodePoint(sender_public_key_source);
    dh.GeneratePrivateKey();
    dh.GeneratePublicKey();

    // Compute the shared secret key
SecByteBlock shared_secret(dh.AgreedValueLength());
dh.Agree(shared_secret, sender_pub);

// Hash the shared secret key to use as the key for the PRNG
byte prng_key[SHA256::DIGESTSIZE];
SHA256().CalculateDigest(prng_key, shared_secret, shared_secret.size());

// Initialize the PRNG with the hashed shared secret key
AutoSeededRandomPool prng(prng_key, sizeof(prng_key));

// Receive the ciphertext
std::string ciphertext;
channel.receive(ciphertext);

// Decrypt the ciphertext using the shared secret key
std::string plaintext;
CBC_Mode<AES>::Decryption decryptor;
decryptor.SetKeyWithIV(prng.GenerateBlock(AES::MAX_KEYLENGTH), AES::MAX_KEYLENGTH, prng.GenerateBlock(AES::BLOCKSIZE));
StringSource(ciphertext, true, new StreamTransformationFilter(decryptor, new StringSink(plaintext)));

return plaintext;
}
